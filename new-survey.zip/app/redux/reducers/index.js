import customizer from './customizer';
import auth from './auth';
import navbar from './navbar/Index';

export default {
  customizer,
  auth,
  navbar,
};
