import axios from 'axios';
export const loadSuggestions = () => dispatch => {};

export const updateStarred = object => dispatch => {};
