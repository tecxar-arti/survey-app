import * as loginAction from './loginActions';
import * as deviceAction from './deviceActions';
import * as distributorAction from './distributorActions';
export default { loginAction, deviceAction, distributorAction };
